1) Extract zip file
2) Open index.php with any text editor to see code
4) to see Data Base open DB folder
3) open https://Baku.Cafe/ in the browser to see the project