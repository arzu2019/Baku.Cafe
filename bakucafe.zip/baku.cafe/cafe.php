<?php
	if(!isset($_GET['id']) && !isset($_GET['name'])) header('Location: https://baku.cafe/');
	include 'part/newhead.php';
	include 'action/metro.php';

	if(isset($_GET['name'])){
		$_GET['name']=str_replace('_', ' ', $_GET['name']);
		$query = $db->prepare('SELECT cafes.name,cafes.id,cafes.metro,cafes.adress'.$lang[$_SESSION['l']]['1'].' adress,cafes.start,cafes.`end`,cafes.parking,cafes.map,cafes.service,cafes.discount,cafes.roomdeposite,cafes.halldeposite,specials.id special  FROM cafes LEFT JOIN specials ON specials.cafe=cafes.id WHERE cafes.name=:name and cafes.deleted=0 GROUP BY cafes.id;');
		$query->execute(array(':name' => $_GET['name']));
	}else{
		$query = $db->prepare('SELECT cafes.name,cafes.id,cafes.metro,cafes.adress'.$lang[$_SESSION['l']]['1'].' adress,cafes.start,cafes.`end`,cafes.parking,cafes.map,cafes.service,cafes.discount,cafes.roomdeposite,cafes.halldeposite,specials.id special  FROM cafes LEFT JOIN specials ON specials.cafe=cafes.id WHERE cafes.id=:id and cafes.deleted=0 GROUP BY cafes.id;');
		$query->execute(array(':id' => $_GET['id']));
	}
	$cafe = $query->fetch();
	if(!isset($cafe['id'])) header('Location: https://baku.cafe/');

	$query = $db->prepare('SELECT features.name'.$lang[$_SESSION['l']]['1'].' name,features.id,features.type FROM features,cf WHERE features.id=cf.feature AND cf.cafe=:id AND cf.hidden=0 ORDER BY features.type,features.id;');
	$query->execute(array(':id' => $cafe['id']));
	$features = $query->fetchAll();

	$day=$wk[date('N')];
	if(isset($_GET['day'])) $day=$wk[$_GET['day']];

	$query = $db->prepare('SELECT text'.$lang[$_SESSION['l']]['1'].' text,id,days FROM specials WHERE cafe=:id AND (specials.days & '.@$day.') > 0 ORDER BY specials.days,rand();');
	$query->execute(array(':id' => $cafe['id']));
	$specials = $query->fetchAll();

	$query = $db->prepare('SELECT p.amount,p.type,p.name'.$lang[$_SESSION['l']]['1'].' name,p.dd'.$lang[$_SESSION['l']]['1'].' dd,p.price,p.cafe,m.id tid,m.name'.$lang[$_SESSION['l']]['1'].' tname FROM products p,menu m WHERE cafe=:id AND m.id=p.type ORDER BY type,p.id');
	$query->execute(array(':id' => $cafe['id']));
	$menu = $query->fetchAll();
?>
	<div id="fb-root"></div>
	<script>(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/ru_RU/sdk.js#xfbml=1&version=v2.10";
	  fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));
	</script>

	<title><?php echo $cafe['name'];?> — Baku.Cafe</title>
	<meta name="description" content="<?php echo $cafe['name'];?> — Look at Menu and Special offers. Calculate the Bill. Reserve a table.">
	<meta property="og:type" content="restaurant.menu" />
	<meta property="og:image" content="https://Baku.Cafe/img/cafe/<?php echo $cafe['id'];?>.jpg" />
	<div class="row shadow bg cafe" itemscope itemtype="http://schema.org/Restaurant">
		<div class="col-12 cover shadow" style="background-image:url('https://Baku.Cafe/img/cover/<?php echo $cafe['id'];?>.jpg')"></div>
		<div class="row main">
			<div class="col-5 pp">
				<img class="shadow" src="https://Baku.Cafe/img/cafe/<?php echo $cafe['id'];?>.jpg" itemprop="logo">
			</div>
			<div class="col-7">
				<div class="block">
					<div class="name" itemprop="name"><?php echo $cafe['name'];?></div>
					<div>
						<a href="https://Baku.Cafe/search.php?metro=<?php echo $cafe['metro'];?>" class="metro"><?php echo $metro[$cafe['metro']][$_SESSION['l']];?></a>
						<span class="add"><?php // print_r($features); 
							foreach ($features as $value) {
								echo ' • <a href="https://Baku.Cafe/search.php?'.$value['id'].'=on">'.$value['name'];
								if($value['type']==2) echo ' '.$l['cuisine'][$_SESSION['l']];
								elseif($value['id']==4 || $value['id']==5) $private=1;
								echo '</a>';
							}
						?></span>
					</div>
				</div>
			</div>
		</div>
		<?php 
			if($cafe['discount']>0){ ?>
				<div class="row col-12 discount">
					<hr>
					<?php echo $l['reserve and get'][$_SESSION['l']];?> <span class="m"><?php echo $cafe['discount'];?>% <?php echo $l['reserve skidki'][$_SESSION['l']];?> <span class="orange">Baku</span>.Cafe <?php echo $l['reserve discount'][$_SESSION['l']];?></span>
					<hr>
				</div>
			<?php }

			if($cafe['end']<=$cafe['start']){
				$end=24+$cafe['end'];
			}else{
				$end=$cafe['end'];
			}

			if(date("H")>=0 && date("H")<$cafe['start']){
				$now=date("H")+24;
			}else{
				$now=date("H");
			}
			if($end- ((date("i") - date("i") % 30) / 30)>$now){
				$start=$now+1;
				$d=$end-$now-1;
			}else{
				$start=$cafe['start'];	
				$d=$end-$start;
			}

			$tmrd=$end-$cafe['start'];

		?>
		<div class="row reserve">
			<form action="https://Baku.Cafe/action/reserve.php?ajax=1" method="POST">
				<div class="col-2">
					<select name="date" data-l="<?php echo $l['Date'][$_SESSION['l']]; ?>">
						<?php if(date("H")>0 && date("H")<$cafe['start'] && date("H")<$cafe['end'])
								$today=-1; else $today=0;
						?>
						<option data-today value="<?php echo date("j",strtotime($today." day")); ?>"><?php echo $l['Today'][$_SESSION['l']].', '.date("j",strtotime($today." day")).' '.$month[date("m",strtotime($today." day"))][$_SESSION['l']];  ;?></option>
						<option value="<?php echo date("j",strtotime("+".($today+1).' day')); ?>"><?php echo $l['Tomorrow'][$_SESSION['l']].', '.(date("j",strtotime("+".($today+1).' day'))).' '.$month[date("m",strtotime("+".($today+1).' day'))][$_SESSION['l']];  ;?></option>
						<?php
							for ($i=2+$today; $i < 7+$today; $i++) { ?>
								<option value="<?php echo date("j",strtotime("+".$i." day")); ?>"><?php echo $week[date("N",strtotime("+".$i." day"))][$_SESSION['l']].', '.date("j",strtotime("+".$i." day")).' '.$month[date("m",strtotime("+".$i." day"))][$_SESSION['l']];  ;?></option>
							<?php }
						?>
					</select>
				</div>
				<input type="hidden" name="cafe" value="<?php echo $cafe['id']; ?>">
				<div class="col-1">
					<select name="time">
						<?php 

							// if minuta < 30 echo :30
							if(date("i")<30 && $start!=$cafe['start']){ ?>
								<option data-today value="<?php echo date("H",strtotime("00:00 + ".($start-1)." hour")).".5"; ?>"><?php echo date("H",strtotime("00:00 + ".($start-1)." hour")).':30'; ?></option>
							<?php }
							for ($i=$start; $i < $start+$d; $i++) { ?>
								<option data-today value="<?php echo date("H",strtotime("00:00 + ".$i." hour")); ?>"><?php echo date("H",strtotime("00:00 + ".$i." hour")).':00'; ?></option>
								<option data-today value="<?php echo date("H",strtotime("00:00 + ".$i." hour")).'.5'; ?>"><?php echo date("H",strtotime("00:00 + ".$i." hour")).':30'; ?></option>
							<?php }

							for ($i=$cafe['start']; $i < $cafe['start']+$tmrd; $i++) { ?>
								<option style="display:none" value="<?php echo date("H",strtotime("00:00 + ".$i." hour")); ?>"><?php echo date("H",strtotime("00:00 + ".$i." hour")).':00'; ?></option>
								<option style="display:none" value="<?php echo date("H",strtotime("00:00 + ".$i." hour")).'.5'; ?>"><?php echo date("H",strtotime("00:00 + ".$i." hour")).':30'; ?></option>
							<?php }
						?>
					</select>
				</div>
				<div class="col-1">
					<select name="per" data-l="<?php echo $l['Table'][$_SESSION['l']]; ?>">
						<?php for ($i=1; $i < 31; $i++) { 
							echo '<option>'.$i.' '.$l['per.'][$_SESSION['l']].'</option>';
						} ?>
					</select>
				</div>
				<div class="col-2 mark">
					<input type="text" name="name" placeholder="<?php echo $l['Your name?'][$_SESSION['l']];?>" data-l="<?php echo $l['Name'][$_SESSION['l']]; ?>">
				</div>
				<div class="col-2 mark">
					<input type="text" name="phone" placeholder="+994 __ ___ __ __" data-l="<?php echo $l['Phone'][$_SESSION['l']]; ?>">
				</div>
				<?php
					if(@$private && $cafe['halldeposite']!='-1'){ ?>
						<div class="col-1 room">
							<select name="private">
								<option value="0"><?php echo $l['Hall'][$_SESSION['l']];?></option>
								<option value="1"><?php echo $l['Private Room'][$_SESSION['l']];?></option>
							</select>
						</div>
					<?php }
				?>
				<div class="<?php if(@$private && $cafe['halldeposite']!='-1'){echo 'col-2 comment';}else {echo 'col-3';} ?>">
					<input type="text" name="comment" placeholder="<?php echo $l['Any comments'][$_SESSION['l']];?>" data-l="<?php echo $l['Сomment'][$_SESSION['l']]; ?>">
				</div>
				<div class="col-1">
					<input type="submit" name="" value="<?php echo $l['Reserve'][$_SESSION['l']];?>">
				</div>
			</form>
		</div>
		<div class="row info">
			<div class="col-5">
				<a href="tel:+994507000512" class="telephone"><span itemprop="telephone">+994 50 7000 512</span></a><br>
				<div class="adress" itemprop="address"><?php echo $cafe['adress'];?></div><br>
				<div class="time">
					<?php 
						echo $l['Open'][$_SESSION['l']].' ';
						if($cafe['start']==$cafe['end']) echo '24/7';
						else{
							echo $l['from'][$_SESSION['l']].' '.$cafe['start'].':00 '.$l['to'][$_SESSION['l']].' '; 
							if($cafe['end']=='-1') echo $l['last customer'][$_SESSION['l']]; else echo $cafe['end'].':00 ';
							echo $l['dek'][$_SESSION['l']];
						} ?>
				</div><br>
				<?php 
				
				if($cafe['roomdeposite']+$cafe['halldeposite']>0){ ?>

					<div class="deposite">
						<?php
							if($cafe['roomdeposite']>0) echo $l['Room Deposite'][$_SESSION['l']].': '.$cafe['roomdeposite'].' AZN';
							if($cafe['halldeposite']>0) echo $l['Hall Deposite'][$_SESSION['l']].': '.$cafe['halldeposite'].' AZN';
						?>
					</div><br>

				<?php 

				}

				?>

				
				<div class="parking">
					<?php if($cafe['parking']>0) echo $l['Parking for'][$_SESSION['l']].' '.$cafe['parking'].' AZN'; elseif($cafe['parking']==0) echo $l['Free parking'][$_SESSION['l']]; else echo $l['No parking'][$_SESSION['l']];?>
				</div>
			</div>
			<div class="col-7 map">
				<iframe src="https://www.google.com/maps/embed?pb=<?php echo $cafe['map'];?>" width="100%" height="222px" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>
		</div>
		<?php if(@$cafe['special']>0){ ?>
		<div class="row discounts" id="discounts">
			<div class="row">
				<div class="h1"><?php echo $l['Special Offers'][$_SESSION['l']];?></div>
				<div class="search">
					<a <?php if(isset($_GET['day']) && $_GET['day']==0) echo 'class="orangebg"'; ?> href="https://Baku.Cafe/<?php echo strtolower(str_replace(' ', '_', $cafe['name']));?>/0#discounts"><?php echo $l['All'][$_SESSION['l']];?></a>
					<a <?php if(@$_GET['day']==date('N') || !isset($_GET['day'])) echo 'class="orangebg"'; ?> href="https://Baku.Cafe/<?php echo strtolower(str_replace(' ', '_', $cafe['name'])).'/'.date('N'); ?>#discounts"><?php echo $l['Today'][$_SESSION['l']];?></a>
					<a <?php if(@$_GET['day']==date('N',strtotime("+ 1 day"))) echo 'class="orangebg"'; ?> href="https://Baku.Cafe/<?php echo strtolower(str_replace(' ', '_', $cafe['name'])).'/'.date('N',strtotime("+ 1 day")); ?>#discounts"><?php echo $l['Tomorrow'][$_SESSION['l']];?></a>
					<a <?php if(@$_GET['day']==date('N',strtotime("+ 2 day"))) echo 'class="orangebg"'; ?> href="https://Baku.Cafe/<?php echo strtolower(str_replace(' ', '_', $cafe['name'])).'/'.date('N',strtotime("+ 2 day")); ?>#discounts"><?php echo $week[date("N",strtotime("+ 2 day"))][$_SESSION['l']]; ?></a>
					<a <?php if(@$_GET['day']==date('N',strtotime("+ 3 day"))) echo 'class="orangebg"'; ?> href="https://Baku.Cafe/<?php echo strtolower(str_replace(' ', '_', $cafe['name'])).'/'.date('N',strtotime("+ 3 day")); ?>#discounts"><?php echo $week[date("N",strtotime("+ 3 day"))][$_SESSION['l']]; ?></a>
					<a <?php if(@$_GET['day']==date('N',strtotime("+ 4 day"))) echo 'class="orangebg"'; ?> href="https://Baku.Cafe/<?php echo strtolower(str_replace(' ', '_', $cafe['name'])).'/'.date('N',strtotime("+ 4 day")); ?>#discounts"><?php echo $week[date("N",strtotime("+ 4 day"))][$_SESSION['l']]; ?></a>
					<a <?php if(@$_GET['day']==date('N',strtotime("+ 5 day"))) echo 'class="orangebg"'; ?> href="https://Baku.Cafe/<?php echo strtolower(str_replace(' ', '_', $cafe['name'])).'/'.date('N',strtotime("+ 5 day")); ?>#discounts"><?php echo $week[date("N",strtotime("+ 5 day"))][$_SESSION['l']]; ?></a>
					<a <?php if(@$_GET['day']==date('N',strtotime("+ 6 day"))) echo 'class="orangebg"'; ?> href="https://Baku.Cafe/<?php echo strtolower(str_replace(' ', '_', $cafe['name'])).'/'.date('N',strtotime("+ 6 day")); ?>#discounts"><?php echo $week[date("N",strtotime("+ 6 day"))][$_SESSION['l']]; ?></a>
					<a <?php if(@$_GET['day']==8) echo 'class="orangebg"'; ?> href="?day=8#discounts"><?php echo $l['banket'][$_SESSION['l']];?></a>	
				</div>
			</div>
			<div class="scroll row">
				<div class="m">
				<?php 
					if(count($specials)!=0){
						foreach ($specials as $special) { ?>
							<div class="col-3">
								<div class="col-12 shadow">
									<img src="https://Baku.Cafe/img/special/<?php echo $special['id'];?>.jpg">
									<div class="discount col-12">
										<div><?php echo $special['text'];?></div>
									</div>
									<div class="hr">
									<?php 
										for ($i=1; $i<65; $i=$i*2){
											if($special['days']&$i){
												echo '<div class="orangebg"></div>';
											}else{
												echo '<div class="greybg"></div>';
											}
										}
									?>
								</div>
								</div>
							</div>
						<?php }
					}else{
						echo '<div style="width:100%;text-align:center;padding:33px 0;">'.$l['no offers'][$_SESSION['l']].'</div>';
					}
				?>
				</div>
			</div>
		</div>
		<?php } ?>
		<div class="row menu shadow">
			<div class="col-12 h2"><?php echo $l['Menu'][$_SESSION['l']];?></div>
			<?php
				foreach ($menu as $key => $product) { 
					if($product['tid']!=@$menu[$key-1]['tid']) echo '<div class="col-12 type" align="center" data-typist="'.$product['tid'].'">'.$menu[$key]['tname'].'</div>'; ?>
					<div class="col-12" <?php if($key%2==0) echo 'style="background-color:#E0E0E0;"';?> data-type="<?php echo $product['tid'];?>">
						<div class="col-10">
							<?php echo $product['name'];?> <?php if($product['amount']>0) echo '<sup>'.$product['amount'].'</sup>';?>
							<span><?php echo $product['dd'];?></span>
						</div>
						<div class="col-2">
							<div class="col-6 price"><?php echo round($product['price'],2); if((int) $product['price']!=$product['price']) echo '0' ; ?> AZN</div>
							<div class="col-6 select">
								<select style="<?php if($key%2==1) echo 'background-color:#E0E0E0;';?>">
									<?php for ($i=0; $i < 10; $i++) { 
										echo '<option value="'.$i.'">'.$i.' '.$l['pcs.'][$_SESSION['l']].'</option>';
									} ?>
								</select>
							</div>
						</div>
					</div>	
				<?php }
			?>
			<div class="row">
				<div class="col-12" align="center">
					<hr>
					<input type="hidden" name="service" value="<?php echo $cafe['service'];?>">
					<input type="hidden" name="discount" value="<?php echo $cafe['discount'];?>">
					<?php
					if($cafe['service']>0){ echo '<div style="padding-bottom:10px">+ '.$l['Service Charge'][$_SESSION['l']].': '.$cafe['service'].'%</div>';}
					if($cafe['discount']>0){ echo '<div style="padding-bottom:10px">'.$l['Baku.Cafe Discount'][$_SESSION['l']].': '.-$cafe['discount'].'%</div>';}
					?>
					<b><?php echo $l['Final Bill'][$_SESSION['l']];?>: <span class="orange"><span id="final">0</span> AZN</span></b>
					<hr>
				</div>
			</div>
			<div class="row col-12">
				<div class="fb-comments" data-href="https://baku.cafe/cafe.php?id=<?php echo $cafe['id'];?>" data-width="100%" data-numposts="10"></div>
			</div>
		</div>
		<meta itemprop="image" content="https://Baku.Cafe/img/cover/<?php echo $cafe['id'];?>.jpg">
		<meta itemprop="url" content="https://Baku.Cafe/<?php echo strtolower(str_replace(' ', '_', $cafe['name']));?>">
		<meta itemprop="menu" content="https://Baku.Cafe/<?php echo strtolower(str_replace(' ', '_', $cafe['name']));?>">
	</div>
	<script>
	    $(document).ready(function() {
	        $(".menu .select select").on('focus', function () {
			    previous = this.value;
			}).change(function() {
				discount=(100-parseInt($('input[name="discount"]').val()))/100;
				service=(100+parseInt($('input[name="service"]').val()))/100;
				$("#final").text((parseFloat($("#final").text())+(service*discount*(this.value-previous)*parseFloat($(this).parent().siblings(".price").text()))).toFixed(2));
				previous = this.value;
			});

			$("div[data-type]").hide();

			$("div[data-typist]").on('click',function() {
				$('div[data-type="'+$(this).attr('data-typist')+'"]').toggle();
			});

			$("select[name='time'] option:not([data-today])").wrap('<span>');
			$("select[name='date']").on('change',function(){
				if($("option:selected", this).is("[data-today]")){
					$("select[name='time'] option:not([data-today])").hide().wrap('<span>');
					$("select[name='time'] option[data-today]").unwrap().show();
					$("select[name='time']").val($("select[name='time'] option[data-today]:first").val());
				}else{
					if($("select[name='time'] option:not([data-today])").parent().prop("tagName")!='SPAN'){
						$("select[name='time'] option:not([data-today])").wrap('<span>');
					}else{
						$("select[name='time'] option[data-today]").hide().wrap('<span>');
					}
					$("select[name='time'] option:not([data-today])").show().unwrap();
					$("select[name='time']").val($("select[name='time'] option:not([data-today]):first").val());
				}
			});

			$("form").on('submit',function(event){
				e=0;
				if($("input[name='name']").val().trim().replace(/[0-9]/g, '').length<2){
					e++;
					$("input[name='name']").addClass("error");
					$("input[name='name']").on('input',function(){
						$(this).removeClass("error");
					})
				}

				if(($("input[name='phone']").val().trim()=='') || ($("input[name='phone']").val().trim().replace(/[^0-9]/g, '').length<9)){
					e++;
					$("input[name='phone']").addClass("error");
					$("input[name='phone']").on('input',function(){
						$(this).removeClass("error");
					})
				}

				if(!e){
					if($("input[name=comment]").val().trim()!='') comment='\n'+$("input[name=comment]").attr('data-l')+': '+$("input[name=comment]").val(); else comment='';
					if(confirm(
						$("input[name=name]").attr('data-l')+': '+$("input[name=name]").val().replace(/[0-9]/g, '')+'\n'+
						$("input[name=phone]").attr('data-l')+': '+$("input[name=phone]").val().replace(/[^0-9]/g, '')+'\n'+
						$("select[name=per]").attr('data-l')+': '+$("select[name=private] option:selected").text()+' '+$("select[name=per] option:selected").text()+' @ '+$(".main .name").text()+'\n'+
						$("select[name=date]").attr('data-l')+': '+$("select[name=time] option:selected").text()+' '+$("select[name=date] option:selected").text()+
						comment)){
						$.ajax({
					    	url: $(this).attr('action'),
					    	type: "post",
					    	dataType: "json",
	        				async: false,
				            data: $(this).serialize(),
					    	success: function(response){
					    		if(response==1){
					    			$("input[type='text']").val('');
					        		alert('The table is requested. You will be contacted within 5 minutes.');
					    		}else{
					    			alert('Reservation form filled wrong.');
					    		}
					        },
					        error: function(){
					        	alert('Something went wrong. Please reload the page and try again.');
					        }
					    });
					}
				}
			    event.preventDefault();
			});
	    });
    </script>
<?php include 'part/footer.php'; ?>