<?php 
include 'connect.php';

date_default_timezone_set('Asia/Baku'); 
$db->prepare('SET NAMES utf8;')->execute(); 
if(!isset($_SESSION['l'])) $_SESSION['l']="0";

$query = $db->prepare('SELECT cafes.id,cafes.name,cafes.start,cafes.`end` FROM cafes WHERE cafes.id=:id and cafes.deleted=0;');
$query->execute(array(':id' => $_POST['cafe']));
$cafe = $query->fetch();

$r=$_POST;

$err=0;

// DAYS

if(date("H")>0 && date("H")<$cafe['start'] && date("H")<$cafe['end']) $today=-1; else $today=0;

for ($i=$today; $i < 7+$today; $i++) $rdays[]=date("j",strtotime("+".$i." day"));

echo '';

if(in_array($_POST['date'], $rdays)){
	echo '';
}else{
	$err++;
}

// TIME

if($cafe['end']<=$cafe['start']){
	$end=24+$cafe['end'];
}else{
	$end=$cafe['end'];
}

if(date("H")>=0 && date("H")<$cafe['start']){
	$now=date("H")+24;
}else{
	$now=date("H");
}
if($end- ((date("i") - date("i") % 30) / 30)>$now){
	$start=$now+1;
	$d=$end-$now-1;
}else{
	$start=$cafe['start'];	
	$d=$end-$start;
}

$tmrd=$end-$cafe['start'];


if(date("i")<30 && $start!=$cafe['start']){
	$rtdtime[]=date("H",strtotime("00:00 + ".($start-1)." hour")).".5";
}

for ($i=$start; $i < $start+$d; $i++) {
	$rtdtime[]=date("H",strtotime("00:00 + ".$i." hour"));
	$rtdtime[]=date("H",strtotime("00:00 + ".$i." hour")).'.5';
}

for ($i=$cafe['start']; $i < $cafe['start']+$tmrd; $i++) {
	$rtmrwtime[]=date("H",strtotime("00:00 + ".$i." hour"));
	$rtmrwtime[]=date("H",strtotime("00:00 + ".$i." hour")).'.5';
}

if(($_POST['date']==$rdays[0] && in_array($_POST['time'],$rtdtime)) || (in_array($_POST['time'],$rtmrwtime))) echo ''; else{
	$err++;
}


// PERSON

if($_POST['per']>=1 && $_POST['per']<=30) echo ''; else {
	$err++;
}

// NAME
$r['name']=ucfirst(mb_strtolower(preg_replace('/[^a-zA-Z]/','',trim($r['name']))));
if(strlen($r['name'])>1) echo ''; else{
	$err++;
}

// PHONE
$r['phone']=preg_replace('/[^0-9]/','',trim($r['phone']));
if(strlen($r['phone'])>8 && strlen($r['phone'])<13){
	echo '';
}else{
	$err++;
}

// ROOM

if((@$_POST['private']==0) || (@$_POST['private']==1) || !isset($_POST['private'])){
	echo '';
	if(!isset($_POST['private'])){
		$private=0;
	}else{
		$private=$_POST['private'];
	}
} else{
	$err++;
}





if($err==0){
	$query = $db->prepare("INSERT INTO `reservations` (`cafe`, `day`, `time`, `persons`, `room`, `name`, `number`, `comment`)
		VALUES (:cafe, :day, :tim, :persons, :room, :name, :numbe, :comment);");
	$query->execute(array(
		':cafe' => $_POST['cafe'],
		':day' => $_POST['date'],
		':tim' => $_POST['time'],
		':persons' => $_POST['per'],
		':room' => '0',
		':name' => $r['name'],
		':numbe' => $r['phone'],
		':comment' => $_POST['comment']
		));

	$msg="We got your reservation request:\n".$_POST['per']." persons at ".$cafe['name'].".\n"."You will be contacted within 5 minutes.";
	mail('misha.akhmedov@gmail.com', 'Reservation', $msg."\nhttps://baku.cafe/akhmedov/reservations.php"); 
	file_get_contents('https://smsc.ru/sys/send.php?login=akhmedov_hh&psw=5a513c7e9c62cf7e66ed4ca70877d4b5&phones=+994507000512&mes='.$msg);
	echo json_encode('1');
}else{
	echo json_encode('0');
}

//INSERT INTO `reservations` (`id`, `cafe`, `day`, `time`, `persons`, `room`, `name`, `number`, `comment`, `date`) VALUES (NULL, '1', '31.10', '18', '3', '0', 'Madzhit', '994507000512', 'dollar kabineti', '2017-10-31 13:41:51');
?>
