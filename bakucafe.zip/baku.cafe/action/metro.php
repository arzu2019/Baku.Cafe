<?php
$metro=array(
	1=>
	array('Ichari Shahar','Ичеришехер','İçərişəhər'),
	array('Sahil','Сахил','Sahil'),
	array('28 May','28 Мая','28 May'),
	array('Ganjlik','Гянджлик','Gənclik'),
	array('Nariman Narimanov','Нариман Нариманов','Nəriman Nərimanov'),
	array('Khatai','Хатаи','Xətai'),
	array('Nizami','Низами','Nizami'),
	array('Bakmil','Бакмил','Bakmil'),
	array('Elmler Akademiyasi','Элмляр Академиясы','Elmlər Akademiyası'),
	array('Inshaatchilar','Иншаатчылар','İnşaatçılar'),
	array('20 Yanvar','20 Января','20 Yanvar'),
	array('Memar Ajami','Мемар Аджеми','Memar Əcəmi'),
	array('Halglar Doslugu','Халглар Достлугу','Xalqlar Dostluğu'),
	array('Ulduz','Улдуз','Ulduz'),
	array('Koroglu','Кероглу','Koroğlu'),
	array('Gara Garayev','Кара Караев','Qara Qarayev'),
	array('Neftchilar','Нефтчиляр','Neftçilər'),
	array('Ahmedli','Ахмедлы','Əhmədli'),
	array('Hazi Aslanov','Ази Асланов','Həzi Aslanov'),
	array('Nasimi','Насими','Nəsimi'),
	array('Azadlıq prospekti','Азадлыг Проспекти','Azadlıq prospekti'),
	array('Darnagul','Дарнагюль','Dərnəgül'),
	array('Avtovaghzal','Автовокзал','Avtovağzal'),
	);

$month=array(
	'',
	array('January','Января','Yanvar'),
	array('February','Февраля','Fevral'),
	array('March','Марта','Mart'),
	array('April','Апреля','Aprel'),
	array('May','Мая','May'),
	array('June','Июня','İyun'),
	array('Jule','Июля','İyul'),
	array('August','Августа','Avqust'),
	array('September','Сентября','Sentabr'),
	array('October','Октября','Oktyabr'),
	array('November','Ноября','Noyabr'),
	array('December','Декабря','Dekabr')
	);

$week=array(
	'',
	array('Monday','Понедельник','Bazar ertəsi'),
	array('Tuesday','Вторник','Çərşənbə axşamı'),
	array('Wednesday','Среда','Çərşənbə'),
	array('Thursday','Четверг','Cümə axşamı'),
	array('Friday','Пятница','Cümə'),
	array('Saturday','Суббота','Şənbə'),
	array('Sunday','Воскресенье','Bazar')
	);

?>
