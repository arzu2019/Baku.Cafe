<?php 
$db = new PDO('mysql:host=localhost;dbname=baku.cafe', 'root'); 
session_start(); 
date_default_timezone_set('Asia/Baku'); 
$db->prepare('SET NAMES utf8;')->execute(); 
if(!isset($_SESSION['l'])) $_SESSION['l']="0";
?>