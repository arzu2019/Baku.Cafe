<?php
	session_start();
	switch ($_GET['l']) {
		case 'ru':
			$_SESSION['l']='1';
			break;
		case 'az':
			$_SESSION['l']='2';
			break;
		case 'en':
			$_SESSION['l']='0';
			break;
	}
	header('Location: '.$_SERVER['HTTP_REFERER']);

?>
