<?php
$type=array(
	'',
	'Drinks',
	'Hot dishes',
	'Cold dishes',
	'Ganjlik',
	'Nariman Narimanov',
	'Shah Ismail Khatai',
	'Nizami',
	'Bakmil',
	'Elmler Akademiyasi',
	'Inshaatchilar',
	'20 Yanvar',
	'Memar Ajami',
	'Halglar Doslugu',
	'Ulduz',
	'Koroglu',
	'Gara Garayev',
	'Neftchilar',
	'Ahmedli',
	'J.Jabbarly',
	'Hazi Aslanov',
	'Nasimi',
	'Azadlıq prospekti',
	'Darnagul',
	'Avtovaghzal'
	);


?>
