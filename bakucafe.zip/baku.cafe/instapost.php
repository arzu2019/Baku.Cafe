



<body style="margin:0;height:100%">

	<div style="width:100%;background-image:url('/img/cover/<?php echo $_GET['id'];?>.jpg');background-size: cover;height:100vw;background-position:center;">
		<img src="/img/cafe/<?php echo $_GET['id'];?>.jpg" style="width:50%;margin:25%;border-radius:50%">
	</div>
		
</body>