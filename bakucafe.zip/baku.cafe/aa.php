<?php
	include('part/newhead.php');
	include 'action/metro.php';

	$day=$wk[date('N')];
	if(isset($_GET['day'])) $day=$wk[$_GET['day']];
	
	$query = $db->prepare('SELECT  specials.text'.$lang[$_SESSION['l']]['1'].' text, specials.id, specials.cafe, cafes.metro,cafes.name FROM specials,cafes WHERE specials.cafe=cafes.id AND cafes.deleted=0 AND (specials.days & '.@$day.') > 0 ORDER BY rand() LIMIT 9;');
	$query->execute();
	$specials = $query->fetchAll();

	$query = $db->prepare('SELECT id,discount FROM `cafes` WHERE deleted=0 AND discount>0 ORDER BY rand() LIMIT 6');
	$query->execute();
	$cafes = $query->fetchAll();

	$query = $db->prepare('SELECT count(id) count FROM `cafes` WHERE deleted=0');
	$query->execute();
	$c = $query->fetch();
?>	
	<title>Baku.Cafe — <?php echo $l['footer'][$_SESSION['l']];?></title>
	<div class="row slide shadow">
		<div class="row search">
			<form method="get" action="search.php">
				<div class="col-2 count input"><?php echo $l['bakinin'][$_SESSION['l']];?> <a href="search.php"><?php echo $c['count'];?> <?php echo $l['restaurants'][$_SESSION['l']];?></a> <?php echo $l['of Baku'][$_SESSION['l']];?></div>
				<div class="col-4"><input placeholder="<?php echo $l['Search restaurant by name'][$_SESSION['l']];?>" name="name" type="text"></div>
				<div class="col-1 input or"><?php echo $l['or'][$_SESSION['l']];?></div>
				<div class="col-3">
					<select name="metro">
						<option value="-1"><?php echo $l['Search restaurant by metrostation'][$_SESSION['l']];?></option>
						<?php 
							foreach ($metro as $k => $m) {
								echo '<option value="'.$k.'">'.$m[$_SESSION['l']].'</option>';
							}
						?>
					</select>
				</div>
				<div class="col-2">
					<input type="submit" name="" value="<?php echo $l['Find a'][$_SESSION['l']];?>">
				</div>
			</form>
			<div class="row well" style="background:none;box-sizing:none">
		<div class="row">
			<div class="col-12 h1" style="display:block"><?php echo $l['discounts'][$_SESSION['l']];?></div>
		</div>
		<div class="row scroll">
			<div class="m">
				<?php 
				foreach ($cafes as $cafe) { ?>
					<a class="col-2" href="cafe.php?id=<?php echo $cafe['id'];?>">
						<div>
							<img src="img/cafe/<?php echo $cafe['id'];?>.jpg">
							<div class="shadow orangebg">
								<table><tr><td>10%</td></tr></table>
							</div>
						</div>
					</a>
				<?php } ?>
			</div>
		</div>
	</div>
		</div>
	</div>

	<div class="row discounts" id="discounts">
		<div class="row">
			<div class="h1"><?php echo $l['Special Offers'][$_SESSION['l']];?></div>
			<div class="search">
				<a <?php if(isset($_GET['day']) && $_GET['day']==0) echo 'class="orangebg"'; ?> href="?day=0#discounts"><?php echo $l['All'][$_SESSION['l']];?></a>
				<a <?php if(@$_GET['day']==date('N') || !isset($_GET['day'])) echo 'class="orangebg"'; ?> href="?day=<?php echo date('N'); ?>#discounts"><?php echo $l['Today'][$_SESSION['l']];?></a>
				<a <?php if(@$_GET['day']==date('N',strtotime("+ 1 day"))) echo 'class="orangebg"'; ?> href="?day=<?php echo date('N',strtotime("+ 1 day")); ?>#discounts"><?php echo $l['Tomorrow'][$_SESSION['l']];?></a>
				<a <?php if(@$_GET['day']==date('N',strtotime("+ 2 day"))) echo 'class="orangebg"'; ?> href="?day=<?php echo date('N',strtotime("+ 2 day")); ?>#discounts"><?php echo $week[date("N",strtotime("+ 2 day"))][$_SESSION['l']]; ?></a>
				<a <?php if(@$_GET['day']==date('N',strtotime("+ 3 day"))) echo 'class="orangebg"'; ?> href="?day=<?php echo date('N',strtotime("+ 3 day")); ?>#discounts"><?php echo $week[date("N",strtotime("+ 3 day"))][$_SESSION['l']]; ?></a>
				<a <?php if(@$_GET['day']==date('N',strtotime("+ 4 day"))) echo 'class="orangebg"'; ?> href="?day=<?php echo date('N',strtotime("+ 4 day")); ?>#discounts"><?php echo $week[date("N",strtotime("+ 4 day"))][$_SESSION['l']]; ?></a>
				<a <?php if(@$_GET['day']==date('N',strtotime("+ 5 day"))) echo 'class="orangebg"'; ?> href="?day=<?php echo date('N',strtotime("+ 5 day")); ?>#discounts"><?php echo $week[date("N",strtotime("+ 5 day"))][$_SESSION['l']]; ?></a>
				<a <?php if(@$_GET['day']==date('N',strtotime("+ 6 day"))) echo 'class="orangebg"'; ?> href="?day=<?php echo date('N',strtotime("+ 6 day")); ?>#discounts"><?php echo $week[date("N",strtotime("+ 6 day"))][$_SESSION['l']]; ?></a>
			</div>
		</div>
		<div class="scroll row">
			<div class="m">
			<?php 
				if(count($specials)!=0){
					foreach ($specials as $cafe) { ?>
						<div class="col-3">
							<a class="col-12 shadow" href="cafe.php?id=<?php echo $cafe['cafe'];?>">	
								<img src="img/special/<?php echo $cafe['id'];?>.jpg">
								<div class="discount col-12">
									<div><?php echo $cafe['text'];?></div>
								</div>
								<hr>
								<div class="name"><?php echo $cafe['name'];?></div>
								<div class="metro"><?php echo $metro[$cafe['metro']][$_SESSION['l']];?></div>
							</a>
						</div>
					<?php }
				}else{
					echo '<div style="width:100%;text-align:center;padding:33px 0;">'.$l['no offers'][$_SESSION['l']].'</div>';
				}
			?>
			</div>
		</div>
	</div>
<?php include 'part/footer.php'; ?>