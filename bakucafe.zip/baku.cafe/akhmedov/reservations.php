<?php
	include '../action/connect.php';
	
?>
<html>
<head>
<title>Reservations</title>
<style>
	h1{text-align:center}
	th{text-align:right}
	input,select{width:100%;padding:5px;}
	input[type="checkbox"]{width: auto}
	.col-4{width:33.33%;float:left}
	label{padding:3px;display:inline-block;}
	th{text-align:left;}
</style>
</head>
<body>
<div style="display:block;margin:0px auto;" align="center">
<?php if(empty($_SESSION['user']["id"])) { 
	header('Location: index.php');
} else { 
	$query = $db->prepare('SELECT reservations.*,cafes.name cname,cafes.phone cnumber FROM reservations,cafes WHERE cafes.id=reservations.cafe ORDER BY reservations.id DESC LIMIT 50;');
	$query->execute();
	$reservations = $query->fetchAll();
?>
	<form action="" method="post">
		<table width="100%" cellspacing="0" border="1" cellpadding="5px">
			<tr>
				<th>Customer Name</th>
				<th>Customer Number</th>
				<th>Cafe</th>
				<th>Cafe Number</th>
				<th>Date</th>
				<th>Time</th>
				<th>Room</th>
				<th>Persons</th>
				<th>Customer Comment</th>
				<th>Date</th>
			</tr>
			<?php

			foreach ($reservations as $key => $reserve) { ?>
				
				<tr>
					<td><?php echo $reserve['name'] ?></td>
					<td><?php echo $reserve['number'] ?></td>
					<td><?php echo $reserve['cname'] ?></td>
					<td><?php echo $reserve['cnumber'] ?></td>
					<td><?php echo $reserve['day'] ?></td>
					<td><?php echo $reserve['time'] ?></td>
					<td><?php echo $reserve['room'] ?></td>
					<td><?php echo $reserve['persons'] ?></td>
					<td><?php echo $reserve['comment'] ?></td>
					<td><?php echo $reserve['date'] ?></td>
				</tr>

			<?php }

			?>
		</table>
	</form>
</div>
<?php } ?>
</body></html>
