<?php
	@include '../action/connect.php';
	
$message="";
if(!empty($_POST["login"])) {
	$query = $db->prepare('SELECT * FROM users WHERE login=:login AND password=:password;');
	$query->execute(array(':login' => $_POST["login"], ':password' => $_POST["password"]));
	$user = $query->fetch();

	if(is_array($user)) {
	$_SESSION['user'] = $user;
	} else {
	$message = "Invalid Username or Password!";
	}
}
if(!empty($_POST["logout"])) {
	$_SESSION['user']["id"] = "";
	session_destroy();
}
?>
<html>
<head>
<title>User Login</title>
<style>
#frmLogin { 
	padding: 20px 60px;
	color: #555;
	display: inline-block;
	border-radius: 4px; 
}
.field-group { 
	margin:15px 0px; 
}
.input-field {
	padding: 8px;width: 200px;
	border: #A3C3E7 1px solid;
	border-radius: 4px; 
}
.form-submit-button {
	background: #65C370;
	border: 0;
	padding: 8px 20px;
	border-radius: 4px;
	color: #FFF;
	text-transform: uppercase; 
}
.member-dashboard {
	padding: 40px;
	background: #D2EDD5;
	color: #555;
	border-radius: 4px;
	display: inline-block;
	text-align:center; 
}
.logout-button {
	color: #09F;
	text-decoration: none;
	background: none;
	border: none;
	padding: 0px;
	cursor: pointer;
}
.error-message {
	text-align:center;
	color:#FF0000;
}
.demo-content label{
	width:auto;
}
button,select{
	display:block;width:50%;margin:0 auto;
}
</style>
</head>
<body>
<div>
<div style="display:block;margin:0px auto;" align="center">
<?php if(empty($_SESSION['user']["id"])) { ?>
<form action="" method="post" id="frmLogin">
	<div class="error-message"><?php if(isset($message)) { echo $message; } ?></div>	
	<div class="field-group">
		<div><label for="login">Username</label></div>
		<div><input name="login" type="text" class="input-field"></div>
	</div>
	<div class="field-group">
		<div><label for="password">Password</label></div>
		<div><input name="password" type="password" class="input-field"> </div>
	</div>
	<div class="field-group">
		<div><input type="submit" name="log" value="Log" class="form-submit-button"></span></div>
	</div>       
</form>
<?php 
} else {
	$query = $db->prepare('SELECT name,id FROM cafes');
	$query->execute();
	$cafes = $query->fetchAll();
?>

	<div class="member-dashboard">
		Welcome <?php echo $_SESSION['user']['login']; ?>, You have successfully logged in!<br>
		<form action="" method="post" id="frmLogout"><input type="submit" name="logout" value="Logout" class="logout-button"></form>
		<hr>
		<div><a href="reservations.php">Reservations</a></div>
		<hr>
		<div><a href="addcafe.php">Add Restaurant</a></div>
		<hr>
		<div>
			<form action="" method="GET">
				<select name="cafe"> 
				<?php
				foreach ($cafes as $cafe) {
					echo '<option value="'.$cafe['id'].'">'.$cafe['name'].'</option>';
				}
				?>
				</select>
				<br>
				<button type="submit" formaction="addmenuelement.php">Add Product to Menu</button>
			</form>
		</div>
		<hr>
	</div>

</div>
</div>
<?php } ?>
</body></html>