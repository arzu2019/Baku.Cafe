<?php
	include '../action/connect.php';

	function mb_ucfirst($str) {
	    $fc = mb_strtoupper(mb_substr($str, 0, 1));
	    return $fc.mb_substr($str, 1);
	}

    function mb_ucwords($str)
	{
		return mb_convert_case($str, MB_CASE_TITLE, "UTF-8");
	}
	
?>
<html>
<head>
<title>Add a Menu Element</title>
<style>
	h1{text-align:center}
	th{text-align:right}
	input,select{width:100%;padding:5px;}
	input[type="checkbox"]{width: auto}
	.col-4{width:33.33%;float:left}
	label{padding:3px;display:inline-block;}
</style>
</head>
<body>
<div style="display:block;margin:0px auto;" align="center">
<?php if(empty($_SESSION['user']["id"])) { 
	header('Location: https://Baku.Cafe/');
} else { 
	$query = $db->prepare('SELECT name,id FROM menu');
	$query->execute();
	$types = $query->fetchAll();

	if(isset($_POST['0'])){
		unset($_POST['0']);
		foreach ($_POST as $key => $value) {
			if(!($key>0)){
				$array[":".$key]=$value;
			}
		}

		$array[':dd']=str_replace(array("(",")"),'',trim(mb_strtolower($array[':dd'])));
		$array[':ddaz']=str_replace(array("(",")"),'',trim(mb_strtolower(str_replace('I','ı',$array[':ddaz']))));
		$array[':ddru']=str_replace(array("(",")"),'',trim(mb_strtolower($array[':ddru'])));

		$array[':name']=mb_strtolower($array[':name']);
		$array[':nameaz']=mb_strtolower(str_replace('I','ı',$array[':nameaz']));
		$array[':nameru']=mb_strtolower($array[':nameru']);

		if($array[':type']<60){
			$array[':name']=mb_ucfirst($array[':name']);
			if ($array[':nameaz'][0]=="i") $array[':nameaz']='İ'.substr($array[':nameaz'], 1); else{
				$array[':nameaz']=mb_ucfirst($array[':nameaz']);
			}
			$array[':nameru']=mb_ucfirst($array[':nameru']);
		}else{
			$array[':name']=mb_ucwords($array[':name']);

			$words = explode(" ", $array[':nameaz']);
			foreach ($words as $key => $value) {
				$words[$key]=str_replace('i','İ',$words[$key]);
			}
			$array[':nameaz']=implode(' ',$words);
			$array[':nameaz']=mb_ucwords($array[':nameaz']);


			$array[':nameru']=mb_ucwords($array[':nameru']);
		}

		$query = $db->prepare("INSERT INTO `products` (`name`, `type`, `cafe`, `amount`, `price`, `dd`, `nameru`, `nameaz`, `ddru`, `ddaz`)
							 VALUES (:name, :type, :cafe, :amount, :price, :dd, :nameru, :nameaz, :ddru, :ddaz);");
		$query->execute($array);
		echo '<h1>ADDED</h1>';
	}
?>
	<form action="" method="post">
		<table width="100%">
			<tr>
				<td align="right">Type : </td>
				<td>
					<select name="type">
					<?php
						foreach ($types as $value) {
							echo '<option ';
							if(@$_POST['type']==$value['id']) echo 'selected ';
							echo 'value="'.$value['id'].'">'.$value['name'].'</option>';
						}
					?>
					</select>
				</td>
			</tr>
			<tr>
				<td align="right" width="30%">Name : </td>
				<td><input name="name" type="text"></td>
			</tr>
			<tr>
				<td align="right">Name in Russian : </td>
				<td><input name="nameru" type="text"></td>
			</tr>
			<tr>
				<td align="right">Name in Azerbaijani : </td>
				<td><input name="nameaz" type="text"></td>
			</tr>
			<tr>
				<td align="right">Additional Info : </td>
				<td><input name="dd" type="text"></td>
			</tr>
			<tr>
				<td align="right">Additional in Russian : </td>
				<td><input name="ddru" type="text"></td>
			</tr>
			<tr>
				<td align="right">Additional in Azerbaijani : </td>
				<td><input name="ddaz" type="text"></td>
			</tr>
			<tr>
				<td align="right">Amount : </td>
				<td><input name="amount" type="number"></td>
			</tr>
			<tr>
				<td align="right">Price : </td>
				<td><input name="price" type="text"></td>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" name="0" value="submit"></td>
			</tr>
		</table>
		<input type="hidden" name="cafe" value="<?php echo $_GET['cafe']; ?>">
	</form>
</div>
<?php } ?>
</body></html>
