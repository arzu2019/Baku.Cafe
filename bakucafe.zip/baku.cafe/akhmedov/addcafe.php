<?php
	include '../action/connect.php';
	
?>
<html>
<head>
<title>Add a Restaurant</title>
<style>
	h1{text-align:center}
	th{text-align:right}
	input,select{width:100%;padding:5px;}
	input[type="checkbox"]{width: auto}
	.col-4{width:33.33%;float:left}
	label{padding:3px;display:inline-block;}
</style>
</head>
<body>
<div style="display:block;margin:0px auto;" align="center">
<?php if(empty($_SESSION['user']["id"])) { 
	header('Location: index.php');
} else { 
	include '../action/metro.php';
	$query = $db->prepare('SELECT id,type,name FROM features;');
	$query->execute();
	$features = $query->fetchAll();
	if(isset($_POST['0'])){
		unset($_POST['0']);
		foreach ($_POST as $key => $value) {
			if(!($key>0)){
				$array[":".$key]=$value;
				unset($_POST[$key]);
			}
		}
		$query = $db->prepare("INSERT INTO `cafes` (`name`, `metro`, `adress`, `adressru`, `adressaz`, `start`, `end`, `parking`, `map`, `service`, `roomdeposite`, `halldeposite`) 
		VALUES (:name, :metro, :adress, :adressru, :adressaz, :start, :end, :parking, :map, :service, :roomdeposite, :halldeposite);");
		$query->execute($array);


		echo $cafeid=$db->lastInsertId();
		foreach ($_POST as $key => $value) {
			if($key>0){
				$key=(int) $key;
				$hidden=0;
				@$fquery.="INSERT INTO `cf` (`cafe`, `feature`, `hidden`) VALUES ($cafeid,$key,$hidden); ";
			}
		}
		$query = $db->prepare($fquery);
		$query->execute();
	}
?>
	<form action="" method="post">
		<table width="100%" cellspacing="10px">
			<tr>
				<th width="25%">Name:</th>
				<td><input required type="text" name="name"></td>
			</tr>
			<tr>
				<th>Metro:</th>
				<td>
					<select name="metro">
						<?php 
							foreach ($metro as $k => $m) {
								echo '<option value="'.$k.'">'.$m[$_SESSION['l']].'</option>';
							}
						?>
					</select>
				</td>
			</tr>
			<tr>
				<th>Adress:</th>
				<td><input required type="text" name="adress"></td>
			</tr>
			<tr>
				<th>Adress Russian:</th>
				<td><input required type="text" name="adressru"></td>
			</tr>

			<tr>
				<th>Adress Azerbaijani:</th>
				<td><input required type="text" name="adressaz"></td>
			</tr>
			<tr>
				<th>Start Time:</th>
				<td><input required type="number" name="start"></td>
			</tr>
			<tr>
				<th>End Time:</th>
				<td><input required type="number" name="end"></td>
			</tr>
			<tr>
				<th>Parking:</th>
				<td><input required type="number" name="parking" placeholder="-1 for No Parking; 0 for Free Parking; n for Paid Parking for N AZN"></td>
			</tr>
			<tr>
				<th>Google Map:</th>
				<td><input required type="text" name="map"></td>
			</tr>
			<tr>
				<th>Service Charge:</th>
				<td><input required type="number" name="service"></td>
			</tr>
			<tr>
				<th>Room Deposite:</th>
				<td><input required type="number" name="roomdeposite"></td>
			</tr>
			<tr>
				<th>Hall Deposite:</th>
				<td><input required type="number" name="halldeposite"></td>
			</tr>
			<tr>
				<td colspan="2">
					<div class="col-4">
						<div><?php echo $l['Type'][$_SESSION['l']];?></div>
						<?php
						foreach ($features as $key => $value){
								if($value['type']=='1'){?>
								<div>
									<input type="checkbox" id="<?php echo $value['id']; ?>" name="<?php echo $value['id']; ?>" <?php if(@$_GET[$value['id']]=='on') echo 'checked'; ?>>
									<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
								</div>
							<?php unset($features[$key]); } }
						?>
					</div>
					<div class="col-4">
						<div><?php echo $l['Feature'][$_SESSION['l']];?></div>
						<?php
						foreach ($features as $key => $value){
								if($value['type']=='0'){?>
								<div>
									<input type="checkbox" id="<?php echo $value['id']; ?>" name="<?php echo $value['id']; ?>" <?php if(@$_GET[$value['id']]=='on') echo 'checked'; ?>>
									<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
								</div>
							<?php unset($features[$key]); } }
						?>
					</div>
					<div class="col-4">
						<div><?php echo $l['Kitchen'][$_SESSION['l']];?></div>
						<?php
						foreach ($features as $key => $value){
								if($value['type']=='2'){?>
								<div>
									<input type="checkbox" id="<?php echo $value['id']; ?>" name="<?php echo $value['id']; ?>" <?php if(@$_GET[$value['id']]=='on') echo 'checked'; ?>>
									<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
								</div>
							<?php unset($features[$key]); } }
						?>
					</div>
				</td>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" name="0"></td>
			</tr>
		</table>
	</form>
</div>
<?php } ?>
</body></html>
