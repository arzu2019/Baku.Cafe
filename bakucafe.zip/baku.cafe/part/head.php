<?php 
	$db = new PDO('mysql:host=localhost;dbname=baku.cafe', 'root');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Online Calculation and Reservation</title>
	<link rel="stylesheet" type="text/css" href="main.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
	<header>
		<div class="middle">
			<div class="telephone right"><a href="tel:+994507000512">+994 50 7000512</a></div>
			<a href="http://localhost/baku.cafe"><b><span class="orange">Baku</span>.Cafe</b></a>
		</div>
	</header>