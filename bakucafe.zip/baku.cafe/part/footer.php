<footer class="row shadow">
	<div class="col-4">
		<div class="col-12">
			<a href="https://Baku.Cafe"><span class="orange">Baku</span>.Cafe</a> — <?php echo $l['footer'][$_SESSION['l']];?>.
		</div>
	</div>
	<div class="col-4 social" align="center">
		<a href="https://fb.com/BakuCafeAz/" target="_blank"><img src="https://Baku.Cafe/img/fb.png"></a>
		<a href="https://instagram.com/baku__cafe" target="_blank"><img src="https://Baku.Cafe/img/ig.png"></a>
	</div>
	<div class="col-4">
		<div class="col-12" align="right">
			<a href="tel:+994507000512">+994 50 7000 512</a>
		</div>
	</div>
</footer>
</body>
</html>