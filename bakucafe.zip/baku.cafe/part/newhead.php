<?php 
	include 'action/connect.php';

	include 'action/translations.php';

	$wk=array('127','1','2','4','8','16','32','64','256');

?>
<!DOCTYPE html>
<html>
<head>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-108580753-1"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-108580753-1');
	</script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="https://Baku.Cafe/newmain.css">
    <script src="https://Baku.Cafe/jquery.js"></script>
    <link rel="shortcut icon" type="image/ico" href="https://Baku.Cafe/img/favicon.ico">
    <meta name="keywords" content="menu, bill, find, restaurant, lounge, cafe, cinema, bakucafe, baku cafe">
	<meta property="og:type" content="website" />
	<meta property="og:url" content="https://<?php echo $_SERVER[HTTP_HOST].$_SERVER[REQUEST_URI]; ?>">
	<?php if($_SERVER[REQUEST_URI]=='/') echo '<meta property="og:img" content="https://Baku.Cafe/img/view1.jpg">'; ?>
</head>
<body>
	<header class="row">
		<div class="col-6">
			<a href="https://Baku.Cafe/"><b><span class="orange">Baku</span>.Cafe</b></a>
		</div>
		<div class="col-6 language">
			<?php if($_SESSION['l']!=1) echo '<a href="https://Baku.Cafe/action/l.php?l=ru"><img src="https://Baku.Cafe/img/ru.png"></a>';?>
			<?php if($_SESSION['l']!=0) echo '<a href="https://Baku.Cafe/action/l.php?l=en"><img src="https://Baku.Cafe/img/en.png"></a>';?>
			<?php if($_SESSION['l']!=2) echo '<a href="https://Baku.Cafe/action/l.php?l=az"><img src="https://Baku.Cafe/img/az.png"></a>';?>
		</div>
	</header>