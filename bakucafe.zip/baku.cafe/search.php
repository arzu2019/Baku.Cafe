<?php
	include('part/newhead.php');
	include 'action/metro.php';
	$get=$_GET;
	$query = $db->prepare('SELECT id,type,name'.$lang[$_SESSION['l']]['1'].' name FROM features;');
	$query->execute();
	$features = $query->fetchAll();

	$q='SELECT cafes.name,cafes.discount,cafes.start,cafes.end,cafes.metro,cafes.id,cafes.adress'.$lang[$_SESSION['l']]['1'].' adress FROM cafes WHERE 1 AND cafes.deleted=0 ';

	if(@$get['metro']>0){
		$q = substr_replace($q, ' AND cafes.metro=:metro ', strpos($q,'WHERE 1')+8, 0);
		$array[':metro']=@$get['metro'];
	}
	unset($get['metro']);

	if(isset($get['name'])){
		$q = substr_replace($q, " AND name LIKE :name ", strpos($q,'WHERE 1')+8, 0);
		$array[':name']='%'.@$get['name'].'%';
	}
	unset($get['name']);

	if(isset($get['0'])){
		$q = substr_replace($q, ' AND cafes.start=6 AND cafes.end=6 ', strpos($q,'WHERE 1')+8, 0);
	}
	unset($get['0']);

	if(count($get)>0){
		$q.=' AND sc.c>=:count AND cafes.id=sc.cafe GROUP BY sc.cafe';
		$q = substr_replace($q, '(SELECT *,COUNT(cf.cafe) c FROM `cf` WHERE (0) group by cf.cafe) sc,', strpos($q,'FROM')+5, 0);
	}

	foreach ($get as $key => $value) {
		@$count++;
		$array[':'.$key]=$key;
		$q = substr_replace($q, ' OR `feature`=:'.$key, strpos($q,'WHERE (')+8, 0);
		$array[':count']=@$count;
	}

	$q.=' ORDER BY cafes.discount DESC, rand()';
	
	$query = $db->prepare($q);
	$query->execute(@$array);
	$cafes = $query->fetchAll();

	$query = $db->prepare('SELECT specials.*,cafes.metro,cafes.name FROM specials,cafes WHERE specials.cafe=cafes.id;');
	$query->execute();
	$specials = $query->fetchAll();

?>
	<title>Baku.Cafe — Search</title>
	<div class="row slide shadow">
		<div class="row search all">
			<form method="get" action="search.php#results">
				<div class="row">
					<div class="col-2 count input"><?php echo $l['bakinin'][$_SESSION['l']];?> <?php echo count($cafes); ?>  <?php echo $l['restaurants'][$_SESSION['l']];?></a> <?php echo $l['of Baku'][$_SESSION['l']];?></div>
					<div class="col-4"><input placeholder="<?php echo $l['Search restaurant by name'][$_SESSION['l']];?>" name="name" type="text" value="<?php echo @$_GET['name']; ?>"></div>
					<div class="col-1 input or"><?php echo $l['or'][$_SESSION['l']];?></div>
					<div class="col-3">
						<select name="metro">
							<option value="-1"><?php echo $l['Search restaurant by metrostation'][$_SESSION['l']];?></option>
							<?php 
								foreach ($metro as $k => $m) { ?>
									<option value="<?php echo $k; ?>" <?php if($_GET['metro']==$k) echo 'selected';?>><?php echo @$m[$_SESSION['l']]; ?></option>
								<?php }
							?>
						</select>
					</div>
					<div class="col-2 c">
						<input type="submit" name="" value="<?php echo $l['Search'][$_SESSION['l']];?>">
					</div>
				</div>
				<div class="row filter">
					<div class="col-4">
						<div class="col-12 h2"><?php echo $l['Type'][$_SESSION['l']];?></div>
						<?php
							foreach ($features as $key => $value){
								if($value['type']=='1'){?>
								<div class="col-6">
									<input type="checkbox" id="<?php echo $value['id']; ?>" name="<?php echo $value['id']; ?>" <?php if(@$_GET[$value['id']]=='on') echo 'checked'; ?>>
									<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
								</div>
								<?php unset($features[$key]); }
							}
						?>
					</div>
					<div class="col-4">
						<div class="col-12 h2"><?php echo $l['Feature'][$_SESSION['l']];?></div>
						<div class="col-6">
							<input type="checkbox" id="at" name="0" <?php if(@$_GET['0']=='on') echo 'checked'; ?>>
							<label for="at"><?php echo $l['Open 24/7'][$_SESSION['l']];?></label>
						</div>
						<?php
						foreach ($features as $key => $value){
							if($value['type']=='0'){?>
								<div class="col-6">
									<input type="checkbox" id="<?php echo $value['id']; ?>" name="<?php echo $value['id']; ?>" <?php if(@$_GET[$value['id']]=='on') echo 'checked'; ?>>
									<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
								</div>
							<?php unset($features[$key]); }
						}
						?>
					</div>
					<div class="col-4">
						<div class="col-12 h2"><?php echo $l['Kitchen'][$_SESSION['l']];?></div>
						<?php
						foreach ($features as $key => $value){
							if($value['type']=='2'){?>
								<div class="col-6">
									<input type="checkbox" id="<?php echo $value['id']; ?>" name="<?php echo $value['id']; ?>" <?php if(@$_GET[$value['id']]=='on') echo 'checked'; ?>>
									<label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
								</div>
							<?php unset($features[$key]); } }
						?>
					</div>
				</div>
				<div class="row col-12 m"><input type="submit" name="" value="<?php echo $l['Search'][$_SESSION['l']];?>"></div>
			</form>
		</div>
	</div>
	<div class="row bg results col-12" id="results" align="center">
		<?php 
			if(isset($cafes['0'])){
				foreach ($cafes as $cafe) { ?>
					<a class="row col-6 shadow" href="https://Baku.Cafe/<?php echo strtolower(str_replace(' ', '_', $cafe['name']));?>" style="background-image:url('img/cover/<?php echo $cafe['id'];?>.jpg')">
						<div class="row shadow inside">
							<?php
								if($cafe['discount']>0){ ?>
									<div class="discount">
										<table class="orangebg shadow"><tr><td><?php echo $cafe['discount']; ?>%</td></tr></table>
									</div>
								<?php }
							?>
							<img class="col-4 shadow" src="img/cafe/<?php echo $cafe['id'];?>.jpg">
							<div class="col-8">
								<div class="col-12 m">
									<span class="name"><?php echo $cafe['name']; ?></span>
									<span class="metro"><?php echo $metro[$cafe['metro']][$_SESSION['l']];?></span>
								</div>
								<div class="col-12 m adress"><?php echo $cafe['adress']; ?></div>
								<div class="time col-12 m">
									<?php 
										if($cafe['start']==$cafe['end']) echo '24/7';
										else{
											echo $cafe['start'].':00 - '; 
											if($cafe['end']=='-1') echo $l['last customer'][$_SESSION['l']]; else echo $cafe['end'].':00 ';
									} ?>
								</div>
							</div>
						</div>
					</a>
				<?php
				}
			}else{ ?>
				<div style="text-align:center;padding:33px;"><?php echo $l['no cafe'][$_SESSION['l']];?></div>
			<?php }
		?>
	</div>
<?php include 'part/footer.php'; ?>